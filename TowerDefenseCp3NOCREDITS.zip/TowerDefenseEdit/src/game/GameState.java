/**
 * Empty, not yet used.
 */
package game;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class GameState {
	// Fields

	List<Animatable> gameObjects;
	List<Animatable> objectsToRemove;
	List<Animatable> objectsToAdd;
	
	int mouseX, mouseY, score, credits, lives;
	boolean mouseClicked, validMousePos;

	// Soon to be used.

	public GameState() {
		gameObjects = new ArrayList<Animatable>();
		objectsToRemove = new ArrayList<Animatable>();
		objectsToAdd = new ArrayList<Animatable>();
		
		mouseX = mouseY = 0;
		mouseClicked = false;
		score = 0;
		lives = 3;
		credits = 50;
	}

	public void addGameObject(Animatable a) {
		objectsToAdd.add(a);
	}
	
	public void removeGameObject(Animatable a) {
		objectsToRemove.add(a);
	}
	
	public void setMouseLocation(int x, int y) {
		mouseX = x;
		mouseY = y;
	}
	
	public int getMouseX() {
		return mouseX;
	}
	
	public int getMouseY() {
		return mouseY;
	}
	
	public boolean isMouseClicked() {
		return mouseClicked;
	}
	
	public void setMouseClicked() {
		mouseClicked = true;
	}
	
	public void consumeMouseClick() {
		mouseClicked = false;
	}
	
	public boolean validMousePos() {
		if (this.getMouseY() < 440) {
			return true;
		}else {
			return false;
		}
	}
	
	public void addScore(int x) {
		score = score + x;
	}
	
	public int getScore() {
		return score;
	}
	
	public void addLives(int x) {
		lives = lives + x;
	}
	
	public int getLives() {
		return lives;
	}
	
	public void addCredits(int x) {
		credits = credits + x;
	}
	
	public int getCredits() {
		return credits;
	}

	public void updateAll(double elapsedTime) {
		for (Animatable a : gameObjects) {
			a.update(elapsedTime);
		}
		
		gameObjects.removeAll(objectsToRemove);
		objectsToRemove.clear();
		
		gameObjects.addAll(objectsToAdd);
		objectsToAdd.clear();
	}

	public void drawAll(Graphics g) {
		for (Animatable a : gameObjects) {
			a.draw(g);
		}
	}
}
