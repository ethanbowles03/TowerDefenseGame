package game;

import java.awt.Graphics;

public class TowerMenuWater implements Animatable {
	private GameState state;
	private int x, y;
	
	public TowerMenuWater(GameState state, int x, int y) {
		this.state = state;
		this.x = x;
		this.y = y;
	}
	
	@Override
	public void update(double timeElapsed) {
		// TODO Auto-generated method stub
		if (state.getMouseX() >= x && state.getMouseX() < x + 50 &&
			state.getMouseY() >= y && state.getMouseY() < y + 50 &&
			state.isMouseClicked()) {
			state.addGameObject(new TowerWaterMoving(state));
		}
	}

	@Override
	public void draw(Graphics g) {
		g.drawImage(ResourceLoader.getLoader().getImage("WaterBottle.png"), x, y, 20, 50, null);
	}

}
